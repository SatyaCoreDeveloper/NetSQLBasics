﻿
    
--Table1:-
create table Person(PersonalID int  primary key Not Null,
                    FirstName varchar(50) Not Null,
                    LastName varchar(50)  Not Null,
                    Discriminator varchar(50)  Not Null
                    );
select * from Person;
insert into Person values(1,'suresh','M','Instructor');
insert into Person values(2,'Ravi','T','Instructor');
insert into Person values(3,'Varun','K','Students');
insert into Person values(4,'Shiva','M','Students');


--Table2:-
create table Course(CourseID int Not Null,
                    Title varchar(50)  Not Null,
                    Credits varchar(50)  Not Null,
                    Technology varchar(50)  Not Null,
                    primary key(CourseID));
select * from Course;
insert into Course values(1,'c#','5','T1');
insert into Course values(2,'js','4','T1');
insert into Course values(3,'html','7','T3');
insert into Course values(4,'mvc','9','T4');
insert into Course values(5,'c','6','T4');


--Table3:-
create table Technology(TechnologyID int Not Null,
                    TechnologyName varchar(50)  Not Null,
                    primary key(TechnologyID));
select * from Technology;
insert into Technology values(1,'TN1');
insert into Technology values(2,'TN2');
insert into  Technology values(3,'TN3');
insert into Technology values(4,'TN4');

--Table4:-
create table StudentEnrollment(
                               StudentEnrollmentID int primary key not null,
							   PersonalID  int Foreign key References Person(PersonalID),
                                 CourseID int FOREIGN KEY REFERENCES Course(CourseID));

select * from StudentEnrollment;
insert into StudentEnrollment values(5,1,1);
insert into StudentEnrollment values(1,2,2);
insert into StudentEnrollment values(2,3,3);
insert into StudentEnrollment values(3,4,4);
insert into StudentEnrollment values(4,4,5);



--Table5:-
create table CourseInstructor(
                                 CourseInstructorID int Not Null,
                                 PersonalID  int Foreign key References Person(PersonalID),
                                 CourseID int FOREIGN KEY REFERENCES Course(CourseID)); 
select * from CourseInstructor;
insert into CourseInstructor values(0,1,1);
insert into CourseInstructor values(1,2,2);
insert into CourseInstructor values(2,3,3);
insert into CourseInstructor values(3,4,4);
insert into CourseInstructor values(4,5,5);

--Query1:-
select firstname, lastname, Discriminator
from Person
where Discriminator='Students';

--Query2:-
select count(Discriminator),Discriminator
from Person
group by Discriminator; 

--Query3:-
select Technology, count(Technology)
from Course
group by Technology;

Drop Table Person ;
Drop Table Course ;
Drop Table Technology;
Drop Table StudentEnrollment;
Drop Table CourseInstructor;
                    --Joins--
--Query1
select c.Title,p.FirstName,p.LastName,p.Discriminator
from Course c
inner join  CourseInstructor s on s.CourseID=c.CourseID
inner join Person p on p.PersonalID=s.PersonalID

--Query2
declare @id int;
select top 1 @id=CourseID from CourseInstructor
group by CourseID order by count(CourseID) Desc
print @id 
select * from CourseInstructor c
inner join Person p on p.PersonalID=c.PersonalID
where c.CourseID=@id


--Query3
select p.FirstName,p.LastName,sum(c.Credits)
from Person p
inner join StudentEnrollment s on p.PersonalID = s.PersonalID
inner join Course c on c.CourseID = s.CourseID
where p.Discriminator='Students' AND (c.Credits)>7
group by p.FirstName,p.LastName;

--Clusrered Index--
create clustered index clsinx1
on Person (PersonalID asc);

create clustered index clsinx2
on Course (CourseID asc);

create clustered index clsinx3
on Technology (TechnologyID asc);

--Non-clustered Index---
create nonclustered index clsinx11
on Person ( Discriminator asc);

create nonclustered index clsinx12
on Course ( Credits asc);

create nonclustered index clsinx13
on Technology ( TechnologyName asc);

--I think we can't use clustered and non-clustered in Student Enrollement table and Courseinstructor tables.
--Because when we created primary key parallelly clustered is created AND we use unique/where conditions we use non-clustered...









