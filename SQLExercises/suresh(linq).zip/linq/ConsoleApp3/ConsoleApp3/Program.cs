﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Person
    {
        public int personid;
        public string firstname;
        public string lastname;
        public string discriminator;
    }
    class Course
    {
        public int courseid;
        public string title;
        public double credits;
        public string technology;
    }
   
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> person = new List<Person>();
            person.Add(new Person() { personid = 1, firstname = "suresh", lastname = "m", discriminator = "instructor" });
            person.Add(new Person() { personid = 2, firstname = "ravi", lastname = "t", discriminator = "instructor" });
            person.Add(new Person() { personid = 3, firstname = "rupa", lastname = "n", discriminator = "student" });
            person.Add(new Person() { personid = 4, firstname = "shiva", lastname = "m", discriminator = "instructor" });
            person.Add(new Person() { personid = 5, firstname = "varun", lastname = "k", discriminator = "student" });
            List<Person> students = person.Where(p => p.discriminator.Equals("student")).ToList();
            Console.WriteLine("No.of Students:-" + students.Count);
            List<Person> instructors = person.Where(i => i.discriminator.Equals("instructor")).ToList();
            Console.WriteLine("No.of Instructors:-" + instructors.Count);
            List<Course> course = new List<Course>();
            course.Add(new Course() { courseid = 1, title = "t1", credits = 7, technology = "c#" });
            course.Add(new Course() { courseid = 2, title = "t2", credits = 6, technology = "html" });
            course.Add(new Course() { courseid = 3, title = "t3", credits = 5.5, technology = "css" });
            course.Add(new Course() { courseid = 4, title = "t4", credits = 9, technology = "js" });
            course.Add(new Course() { courseid = 5, title = "t5", credits = 6, technology = "c#" });
            var technologies = course.GroupBy(n => n.technology).Select(m=>new{technology=m.Key}).ToList();
            foreach(var c in technologies)
            {
                Console.WriteLine("Technology:-"+c.technology);
            }
            double count = 0;
            Console.WriteLine("Enter technology name");
            string a =Console.ReadLine();
            List<Course> ts = course.Where(i => i.technology.Equals(a)).ToList();
            foreach(var list in ts)
            {
                count = count + list.credits;
            }
            Console.WriteLine("total credits = " + count);
            Console.ReadLine(); 
        }
    }
}
