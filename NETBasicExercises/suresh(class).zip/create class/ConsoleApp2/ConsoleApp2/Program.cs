﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Person
    {
        public int Personid=1;
        public string Firstname = "Suresh";
        public string Lastname = "Maadana";
        public string Discriminator = "student";
    }
    public class Course
    {
        public int Courseid = 2;
        public string Title = "course";
        public string Credits = "10";
        public string Technology = "c#";
    }
    public class Technology
    {
        public int Technologyid = 3;
        public string Technologyname = "T1";
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person obj1 = new Person();
            Course obj2 = new Course();
            Technology obj3 = new Technology();
            Console.WriteLine("Personid:{0} Firstname:{1} Lastname:{2} Discriminator:{3}", obj1.Personid, obj1.Firstname, obj1.Lastname, obj1.Discriminator);
            Console.WriteLine("Courseid:{0} Title:{1} Credits:{2} Technology:{3}", obj2.Courseid,obj2.Title,obj2.Credits,obj2.Technology);
            Console.WriteLine("Technologyid:{0} Technologyname:{1}", obj3.Technologyid, obj3.Technologyname);
            Console.ReadLine();
        }
    }
}
