﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Autoincrement
    {
        public  static int i=1;
        public int autoincrement()
        {
            return i++;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Autoincrement obj = new Autoincrement();
            for(int j=0; ;j++)
                {
                 Console.WriteLine(obj.autoincrement());
                }

            Console.ReadLine();
        }
    }
}
